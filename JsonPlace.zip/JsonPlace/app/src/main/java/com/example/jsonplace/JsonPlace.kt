package com.example.jsonplace

class JsonPlace : ArrayList<JsonPlaceItem>()