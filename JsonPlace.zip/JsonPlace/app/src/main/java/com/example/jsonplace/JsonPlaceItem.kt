package com.example.jsonplace

data class JsonPlaceItem(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int

)